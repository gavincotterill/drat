library(testthat)
library(rnetcarto)

test_check("rnetcarto")
